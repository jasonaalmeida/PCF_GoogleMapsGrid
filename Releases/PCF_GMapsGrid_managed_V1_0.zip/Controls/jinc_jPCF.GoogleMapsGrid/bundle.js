var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./GoogleMapsGrid/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./GoogleMapsGrid/index.ts":
/*!*********************************!*\
  !*** ./GoogleMapsGrid/index.ts ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar GoogleMapsGrid =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function GoogleMapsGrid() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  GoogleMapsGrid.prototype.init = function (context, notifyOutputChanged, state, container) {\n    //debugger;\n    console.log(\"Init Function\"); //control initialization code\n\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this._notifyOutputChanged = notifyOutputChanged; //this._refreshData = this.refreshData.bind(this);\n    //Append Google Maps Script reference\n\n    var headerScript = document.createElement(\"script\");\n    headerScript.type = 'text/javascript';\n    headerScript.id = \"GoogleHeaderScript\";\n    var apiKey = context.parameters.googleMapsAPIKey.raw != null && context.parameters.googleMapsAPIKey.raw != \"val\" ? context.parameters.googleMapsAPIKey.raw : \"\";\n    headerScript.src = \"https://maps.googleapis.com/maps/api/js?key=\" + apiKey;\n    headerScript.onload = this.initMap;\n    document.body.appendChild(headerScript);\n    this._mapDiv = document.createElement(\"div\");\n\n    this._mapDiv.setAttribute(\"id\", \"mapDiv\");\n\n    this._mapDiv.setAttribute(\"style\", \"position:relative;width:100%;height:80vh;border-style: solid;margin:auto;\");\n\n    this._container.appendChild(this._mapDiv); //Associate controls to container\n\n\n    container.appendChild(this._container);\n  };\n\n  GoogleMapsGrid.prototype.initMap = function () {\n    //debugger;\n    console.log(\"Init map called\");\n    this.mapOptions = {\n      zoom: 10,\n      scrollwheel: false,\n      center: new google.maps.LatLng(0, 0)\n    };\n    this.gMap = new google.maps.Map(document.getElementById('mapDiv'), this.mapOptions);\n    var self = this; //Get Users Current Location\n\n    if (navigator.geolocation) {\n      navigator.geolocation.getCurrentPosition(function (position) {\n        var pos = {\n          lat: position.coords.latitude,\n          lng: position.coords.longitude\n        };\n        self.gMap.setCenter(pos);\n        self.mapOptions.center = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);\n      }, function () {//handleLocationError(true, infoWindow, map.getCenter());\n        //do nothing because we have set the center as 0 0 as a backup\n      });\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  GoogleMapsGrid.prototype.updateView = function (context) {\n    // Add code to update control view\n    console.log(\"update view called\");\n    this.initMap();\n    var LocalMap = this.gMap;\n    var dataSet = context.parameters.mapDataSet;\n    var latField = context.parameters.latFieldName.raw ? context.parameters.latFieldName.raw : \"\";\n    var longField = context.parameters.longFieldName.raw ? context.parameters.longFieldName.raw : \"\";\n\n    if (dataSet == null || latField == \"\" || longField == \"\") {\n      return;\n    }\n\n    var infowindow = new google.maps.InfoWindow();\n\n    for (var i = 0; i < context.parameters.mapDataSet.paging.totalResultCount; i++) {\n      var recordId = dataSet.sortedRecordIds[i];\n      var record = dataSet.records[recordId];\n      var content = this.buildInforWindow(dataSet.getTargetEntityType(), recordId, record, dataSet.columns);\n      var myLatLng = {\n        lat: record.getValue(latField),\n        lng: record.getValue(longField)\n      };\n      var marker = new google.maps.Marker({\n        position: myLatLng,\n        map: this.gMap,\n        title: record.getValue(\"name\")\n      });\n      google.maps.event.addListener(marker, 'click', function (marker, content) {\n        return function () {\n          infowindow.setContent(content);\n          infowindow.open(LocalMap, marker);\n        };\n      }(marker, content));\n    }\n\n    this.gMap = LocalMap;\n  };\n  /**\r\n   * Function to build an information window for a given location marker\r\n   * @param recEntityType\r\n   * @param recId\r\n   * @param rec\r\n   * @param cols The columns to use to display information in the info window\r\n   */\n\n\n  GoogleMapsGrid.prototype.buildInforWindow = function (recEntityType, recId, rec, cols) {\n    var divTag = document.createElement(\"div\");\n    divTag.id = recId;\n    var content = \"\";\n    var primaryField = this._context.parameters.primaryFieldName.raw ? this._context.parameters.primaryFieldName.raw : \"\";\n    var titleString = rec.getValue(primaryField).toString();\n    var titleTag = document.createElement(\"a\");\n    titleTag.href = \"#\";\n    titleTag.className = \"infoTitle\";\n    titleTag.innerHTML = titleString;\n    divTag.appendChild(titleTag); //initialise table\n\n    content = content.concat(\"</br></br><table class='infotable'>\");\n\n    for (var i = 0; i < cols.length; i++) {\n      //add exclusion criteria to exclude lat,long, primary field and id\n      if (cols[i].name != this._context.parameters.latFieldName.raw && cols[i].name != this._context.parameters.primaryFieldName.raw && cols[i].name != this._context.parameters.longFieldName.raw) {\n        //create row of data\n        content = content.concat(\"<tr><th class='infoth'>\" + cols[i].displayName + \": </th>\");\n        var strValue = rec.getFormattedValue(cols[i].name) != null ? rec.getFormattedValue(cols[i].name) : \"\";\n        content = content.concat(\"<td class='infotd'> \" + strValue + \"</td></tr>\");\n      }\n    } //close table\n\n\n    content = content.concat(\"</table>\");\n    var contentHTML = document.createElement(\"span\");\n    contentHTML.innerHTML = content;\n    divTag.appendChild(contentHTML);\n    google.maps.event.addDomListener(titleTag, 'click', this.openRecord.bind(null, this._context, titleString, recEntityType, recId), false);\n    return divTag;\n  };\n  /**\r\n   * Function to open a record based on supplied record details\r\n   * @param context\r\n   * @param recName\r\n   * @param recType\r\n   * @param recId\r\n   */\n\n\n  GoogleMapsGrid.prototype.openRecord = function (context, recName, recType, recId) {\n    //var recordRef: ComponentFramework.EntityReference = {\n    //    entityType: recType,\n    //    id: recId,\n    //    name: recName\n    //};\n    var entityFormOptions = {\n      entityName: recType,\n      entityId: recId\n    }; // context.parameters.mapDataSet.openDatasetItem(recordRef);\n\n    context.navigation.openForm(entityFormOptions); //the other option is to build a url using context.page.appId?\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  GoogleMapsGrid.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  GoogleMapsGrid.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return GoogleMapsGrid;\n}();\n\nexports.GoogleMapsGrid = GoogleMapsGrid;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./GoogleMapsGrid/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('jPCF.GoogleMapsGrid', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GoogleMapsGrid);
} else {
	var jPCF = jPCF || {};
	jPCF.GoogleMapsGrid = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GoogleMapsGrid;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}